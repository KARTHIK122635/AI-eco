"""
Test Suite for Stage 3 Gemini LLM Enrichment Pipeline
======================================================
Covers all 21 test requirements specified in Stage 3 Execution Brief:
1. Actual Gemini provider configuration
2. API authentication failure handling
3. API quota and rate-limit handling (HTTP 429)
4. Timeout handling
5. Malformed JSON response parsing
6. Invalid field types handling
7. Unsupported claims detection
8. Contradictory evidence detection
9. Negation and attribution preservation
10. Numerical value and date mismatches
11. Partial list evidence detection
12. Unique operation and proposal IDs
13. Bounded retry and backoff handling
14. Source quotation traceability
15. Pending approval protection
16. Rejected proposal protection
17. Explicit approval requirements
18. Canonical database write protection
19. Historical audit log preservation (366 archive rows)
20. Transactional rollback on database failure
21. No offline fallback masquerading as Gemini
"""

import json
import os
import shutil
import sqlite3
import tempfile
import unittest
from unittest.mock import MagicMock, patch

import httpx

from core.enrichment.engine import EnrichmentEngine
from core.enrichment.schemas import (
    EnrichmentResult,
    ValidationStatus,
    compute_canonical_source_version,
)
from core.enrichment.validator import EvidenceValidator
from src.stage3.apply_approved import ApprovedUpdateApplicator
from src.stage3.gemini_enrichment import GeminiEnrichmentRunner, compute_file_hash
from src.stage3.gemini_provider import (
    DEFAULT_GEMINI_MODEL,
    GeminiEnrichmentResponse,
    GeminiProvider,
    GeminiUsage,
    redact_secrets,
)
from src.stage3.review_proposals import ReviewQueueManager


class TestGeminiProviderConfiguration(unittest.TestCase):
    """Test 1: Actual Gemini provider configuration."""

    def test_provider_defaults_and_env(self):
        # Default model is gemini-3.1-flash-lite
        provider = GeminiProvider(api_key="mock-test-key-123")
        self.assertEqual(provider.model_id, DEFAULT_GEMINI_MODEL)
        self.assertEqual(provider.api_key, "mock-test-key-123")
        self.assertEqual(provider.max_retries, 3)

        # Custom model override
        custom_provider = GeminiProvider(api_key="mock-test-key-456", model_id="gemini-1.5-pro")
        self.assertEqual(custom_provider.model_id, "gemini-1.5-pro")

    def test_secret_redaction(self):
        dummy_secret = "MOCK_SECRET_REDACTION_TOKEN_TEST"
        msg = f"Connecting with key={dummy_secret} to endpoint"
        redacted = redact_secrets(msg, dummy_secret)
        self.assertNotIn(dummy_secret, redacted)
        self.assertIn("[REDACTED_GEMINI_KEY]", redacted)


class TestGeminiAuthAndErrorHandling(unittest.TestCase):
    """Tests 2, 3, 4, 13: Auth, rate limits, timeouts, retries."""

    def test_missing_api_key_validation(self):
        """Test 2a: Missing API key fails validation cleanly."""
        provider = GeminiProvider(api_key="")
        is_valid, msg = provider.validate_api_key()
        self.assertFalse(is_valid)
        self.assertIn("GEMINI_API_KEY is not configured", msg)

    @patch("httpx.Client.post")
    def test_auth_failure_http_401(self, mock_post):
        """Test 2b: HTTP 401 raises error immediately without infinite retries."""
        mock_resp = MagicMock()
        mock_resp.status_code = 401
        mock_resp.text = "API_KEY_INVALID: API key not valid."
        mock_post.return_value = mock_resp

        provider = GeminiProvider(api_key="invalid-key")
        with self.assertRaises(RuntimeError) as ctx:
            provider.generate_content_rest("Test prompt", "req-1")
        self.assertIn("HTTP 401", str(ctx.exception))
        self.assertEqual(mock_post.call_count, 1)  # Non-retryable

    @patch("httpx.Client.post")
    def test_rate_limit_retry_http_429(self, mock_post):
        """Test 3 & 13: HTTP 429 triggers bounded retries with backoff."""
        mock_resp_429 = MagicMock()
        mock_resp_429.status_code = 429
        mock_resp_429.text = "Resource has been exhausted (rate limit)."

        mock_resp_200 = MagicMock()
        mock_resp_200.status_code = 200
        mock_resp_200.json.return_value = {
            "candidates": [
                {
                    "content": {
                        "parts": [
                            {
                                "text": json.dumps({
                                    "record_id": "rec-1",
                                    "entity_type": "startup",
                                    "target_field": "ai_specialization",
                                    "original_value": None,
                                    "proposed_value": "Foundation Models & LLMs",
                                    "evidence": "LLMs",
                                    "evidence_url": "http://example.com",
                                    "evidence_quote": "LLMs",
                                    "reasoning": "Reason",
                                    "confidence": 0.9,
                                    "status": "VERIFIED",
                                    "limitations": "",
                                    "model_id": "gemini-2.5-flash",
                                    "provider": "google-gemini",
                                })
                            }
                        ]
                    }
                }
            ],
            "usageMetadata": {"promptTokenCount": 50, "candidatesTokenCount": 20, "totalTokenCount": 70}
        }

        # First call 429, second call 200
        mock_post.side_effect = [mock_resp_429, mock_resp_200]

        provider = GeminiProvider(api_key="valid-key", retry_delay_base=0.01)
        data, usage = provider.generate_content_rest("Test prompt", "req-2")
        self.assertEqual(mock_post.call_count, 2)
        self.assertEqual(usage.total_tokens, 70)

    @patch("httpx.Client.post")
    def test_timeout_handling(self, mock_post):
        """Test 4: Timeout triggers bounded retry and records failure."""
        mock_post.side_effect = httpx.TimeoutException("Timed out")
        provider = GeminiProvider(api_key="valid-key", max_retries=2, retry_delay_base=0.01)
        resp = provider.enrich_candidate(
            record_id="rec-1",
            entity_type="startup",
            target_field="ai_specialization",
            original_value=None,
            canonical_source_text="Some text",
            source_url="http://example.com",
            request_id="req-timeout",
        )
        self.assertFalse(resp.is_success)
        self.assertEqual(resp.status, "FAILED")
        self.assertIn("timed out", resp.error_message.lower())
        self.assertEqual(mock_post.call_count, 3)  # Initial + 2 retries


class TestGeminiResponseParsingAndValidation(unittest.TestCase):
    """Tests 5, 6, 7, 8, 9, 10, 11, 14: Structured parsing & EvidenceValidator."""

    @patch("httpx.Client.post")
    def test_malformed_json_response(self, mock_post):
        """Test 5: Malformed JSON handled gracefully as FAILED status."""
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {
            "candidates": [{"content": {"parts": [{"text": "NOT VALID JSON {foo: bar"}]}}]
        }
        mock_post.return_value = mock_resp

        provider = GeminiProvider(api_key="valid-key")
        resp = provider.enrich_candidate(
            record_id="rec-1",
            entity_type="startup",
            target_field="ai_specialization",
            original_value=None,
            canonical_source_text="Some text",
            source_url="http://example.com",
            request_id="req-malformed",
        )
        self.assertFalse(resp.is_success)
        self.assertEqual(resp.status, "FAILED")
        self.assertIn("Malformed JSON", resp.error_message)

    def test_invalid_taxonomy_field_type(self):
        """Test 6: Invalid taxonomy value receives FAILED status."""
        res = EnrichmentResult(
            attempt_id="att-1",
            record_id="prelim_startup_6631243200679035785",
            entity_type="startup",
            field_name="ai_specialization",
            original_value=None,
            enriched_value="Fabricated AI Category That Does Not Exist",
            source_url="http://example.com",
            evidence="Fabricated text",
            source_version="abc",
            confidence_score=0.9,
            enrichment_method="llm_extraction",
            provider="google-gemini",
            model="gemini-2.5-flash",
            enriched_at="2026-11-22T00:00:00Z",
            validation_status="NEEDS_REVIEW",
            validation_rationale="",
        )
        status, rationale = EvidenceValidator.validate_enrichment(res, "Fabricated text")
        self.assertEqual(status, ValidationStatus.FAILED)
        self.assertIn("Taxonomy Violation", rationale)

    def test_unsupported_claims(self):
        """Test 7: Unsupported claims never receive VERIFIED status."""
        res = EnrichmentResult(
            attempt_id="att-2",
            record_id="arxiv_2611_26232",
            entity_type="paper",
            field_name="methodology",
            original_value=None,
            enriched_value="We utilize quantum annealing for training models.",
            source_url="http://example.com",
            evidence="This paper proposes a stochastic gradient descent algorithm.",
            source_version="abc",
            confidence_score=0.9,
            enrichment_method="llm_extraction",
            provider="google-gemini",
            model="gemini-2.5-flash",
            enriched_at="2026-11-22T00:00:00Z",
            validation_status="NEEDS_REVIEW",
            validation_rationale="",
        )
        status, rationale = EvidenceValidator.validate_enrichment(
            res, "This paper proposes a stochastic gradient descent algorithm."
        )
        self.assertNotEqual(status, ValidationStatus.VERIFIED)

    def test_contradictory_negation_evidence(self):
        """Test 8 & 9: Evidence with negation rejects affirmative claims."""
        res = EnrichmentResult(
            attempt_id="att-3",
            record_id="arxiv_2611_26232",
            entity_type="paper",
            field_name="methodology",
            original_value=None,
            enriched_value="We manufacture autonomous surgical robots.",
            source_url="http://example.com",
            evidence="We do not manufacture autonomous surgical robots.",
            source_version="abc",
            confidence_score=0.9,
            enrichment_method="llm_extraction",
            provider="google-gemini",
            model="gemini-2.5-flash",
            enriched_at="2026-11-22T00:00:00Z",
            validation_status="NEEDS_REVIEW",
            validation_rationale="",
        )
        status, rationale = EvidenceValidator.validate_enrichment(
            res, "We do not manufacture autonomous surgical robots."
        )
        self.assertEqual(status, ValidationStatus.FAILED)
        self.assertIn("Semantic Contradiction", rationale)

    def test_numerical_mismatch(self):
        """Test 10: Date / numerical discrepancy triggers failure."""
        res = EnrichmentResult(
            attempt_id="att-4",
            record_id="prelim_startup_6631243200679035785",
            entity_type="startup",
            field_name="description",
            original_value=None,
            enriched_value="The company was founded in 2022.",
            source_url="http://example.com",
            evidence="The company was founded in 2020.",
            source_version="abc",
            confidence_score=0.9,
            enrichment_method="llm_extraction",
            provider="google-gemini",
            model="gemini-2.5-flash",
            enriched_at="2026-11-22T00:00:00Z",
            validation_status="NEEDS_REVIEW",
            validation_rationale="",
        )
        status, rationale = EvidenceValidator.validate_enrichment(
            res, "The company was founded in 2020."
        )
        self.assertEqual(status, ValidationStatus.FAILED)
        self.assertIn("Semantic Mismatch", rationale)
        self.assertIn("2022", rationale)

    def test_partial_list_evidence(self):
        """Test 11: List where only partial elements are grounded requires review or fails."""
        res = EnrichmentResult(
            attempt_id="att-5",
            record_id="job_e98b00bb44e6a41d",
            entity_type="job",
            field_name="technologies",
            original_value=None,
            enriched_value=["Python", "QuantumCryptography"],
            source_url="http://example.com",
            evidence="Requires strong Python skills.",
            source_version="abc",
            confidence_score=0.9,
            enrichment_method="llm_extraction",
            provider="google-gemini",
            model="gemini-2.5-flash",
            enriched_at="2026-11-22T00:00:00Z",
            validation_status="NEEDS_REVIEW",
            validation_rationale="",
        )
        status, rationale = EvidenceValidator.validate_enrichment(
            res, "Requires strong Python skills."
        )
        self.assertNotEqual(status, ValidationStatus.VERIFIED)

    def test_source_quotation_traceability(self):
        """Test 14: Evidence excerpt must be traceable to original canonical source text."""
        res = EnrichmentResult(
            attempt_id="att-6",
            record_id="prelim_startup_6631243200679035785",
            entity_type="startup",
            field_name="ai_specialization",
            original_value=None,
            enriched_value="Foundation Models & LLMs",
            source_url="http://example.com",
            evidence="Completely hallucinated quote not present in source",
            source_version="abc",
            confidence_score=0.9,
            enrichment_method="llm_extraction",
            provider="google-gemini",
            model="gemini-2.5-flash",
            enriched_at="2026-11-22T00:00:00Z",
            validation_status="NEEDS_REVIEW",
            validation_rationale="",
        )
        status, rationale = EvidenceValidator.validate_enrichment(
            res, "Company Name: Mistral AI\nAI Focus: foundation model; ai; artificial intelligence; llm"
        )
        self.assertEqual(status, ValidationStatus.FAILED)
        self.assertIn("Rule 2 Violation", rationale)
        self.assertIn("not be traced", rationale)


class TestApprovalQueueAndWriteProtection(unittest.TestCase):
    """Tests 12, 15, 16, 17, 18, 19, 20, 21: Safety, approval workflows, write protection."""

    def setUp(self):
        self.temp_dir = tempfile.mkdtemp(prefix="test_stage3_")
        self.temp_db = os.path.join(self.temp_dir, "test_ecosystem.db")
        # Copy active DB to temporary location for destructive/test operations
        shutil.copyfile("data/normalized/ai_ecosystem.db", self.temp_db)

        self.temp_results = os.path.join(self.temp_dir, "results.jsonl")
        self.temp_queue = os.path.join(self.temp_dir, "queue.csv")
        self.temp_summary = os.path.join(self.temp_dir, "summary.json")

    def tearDown(self):
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def test_unique_operation_and_proposal_ids(self):
        """Test 12: Unique operation IDs generated per candidate."""
        import uuid
        ids = {str(uuid.uuid4()) for _ in range(100)}
        self.assertEqual(len(ids), 100)

    def test_pending_approval_protection(self):
        """Test 15: Cannot apply proposals with status PENDING_APPROVAL."""
        applicator = ApprovedUpdateApplicator(
            db_path=self.temp_db,
            queue_csv_path=self.temp_queue,
            results_jsonl_path=self.temp_results,
        )
        # Create dummy proposal with PENDING_APPROVAL
        proposal = {
            "proposal_id": "prop-pending-1",
            "record_id": "prelim_startup_6631243200679035785",
            "entity_type": "startup",
            "field_name": "ai_specialization",
            "original_value": None,
            "proposed_value": "Foundation Models & LLMs",
            "validation_status": "VERIFIED",
            "approval_status": "PENDING_APPROVAL",
        }
        with open(self.temp_results, "w", encoding="utf-8") as f:
            f.write(json.dumps(proposal) + "\n")

        success, msg = applicator.apply_proposal("prop-pending-1", confirm_authorized=True)
        self.assertFalse(success)
        self.assertIn("APPROVAL VIOLATION", msg)

    def test_rejected_proposal_protection(self):
        """Test 16: Cannot apply rejected proposals."""
        applicator = ApprovedUpdateApplicator(
            db_path=self.temp_db,
            queue_csv_path=self.temp_queue,
            results_jsonl_path=self.temp_results,
        )
        proposal = {
            "proposal_id": "prop-rejected-1",
            "record_id": "prelim_startup_6631243200679035785",
            "entity_type": "startup",
            "field_name": "ai_specialization",
            "original_value": None,
            "proposed_value": "Foundation Models & LLMs",
            "validation_status": "VERIFIED",
            "approval_status": "REJECTED",
        }
        with open(self.temp_results, "w", encoding="utf-8") as f:
            f.write(json.dumps(proposal) + "\n")

        success, msg = applicator.apply_proposal("prop-rejected-1", confirm_authorized=True)
        self.assertFalse(success)
        self.assertIn("APPROVAL VIOLATION", msg)

    def test_explicit_approval_requirements(self):
        """Test 17: Cannot apply without confirm_authorized=True flag."""
        applicator = ApprovedUpdateApplicator(
            db_path=self.temp_db,
            queue_csv_path=self.temp_queue,
            results_jsonl_path=self.temp_results,
        )
        success, msg = applicator.apply_proposal("prop-1", confirm_authorized=False)
        self.assertFalse(success)
        self.assertIn("WRITE PROTECTION ABORT", msg)

    def test_canonical_database_write_protection_and_hash(self):
        """Test 18: GeminiEnrichmentRunner dry-run leaves DB byte-identical."""
        pre_hash = compute_file_hash("data/normalized/ai_ecosystem.db")
        runner = GeminiEnrichmentRunner(db_path="data/normalized/ai_ecosystem.db")
        success = runner.run_dry_run()
        self.assertTrue(success)
        post_hash = compute_file_hash("data/normalized/ai_ecosystem.db")
        self.assertEqual(pre_hash, post_hash)

    def test_historical_audit19_log_preservation(self):
        """Test 19: Historical Audit 19 archive rows remain exactly 366 rows."""
        conn = sqlite3.connect("data/normalized/ai_ecosystem.db")
        cursor = conn.cursor()
        cursor.execute("SELECT count(*) FROM audit19_enrichment_audit_log_archive")
        count = cursor.fetchone()[0]
        conn.close()
        self.assertEqual(count, 366)

    def test_rollback_on_database_failure(self):
        """Test 20: Transaction rollback on database failure."""
        applicator = ApprovedUpdateApplicator(
            db_path=self.temp_db,
            queue_csv_path=self.temp_queue,
            results_jsonl_path=self.temp_results,
        )
        # Create an approved proposal targeting a non-existent table/record
        proposal = {
            "proposal_id": "prop-bad-table",
            "record_id": "non_existent_rec_9999",
            "entity_type": "startup",
            "field_name": "ai_specialization",
            "original_value": None,
            "proposed_value": "Foundation Models & LLMs",
            "validation_status": "VERIFIED",
            "approval_status": "APPROVED",
        }
        with open(self.temp_results, "w", encoding="utf-8") as f:
            f.write(json.dumps(proposal) + "\n")

        success, msg = applicator.apply_proposal("prop-bad-table", confirm_authorized=True)
        self.assertFalse(success)
        self.assertIn("not found in canonical table", msg)

    def test_no_offline_fallback_masquerading(self):
        """Test 21: Never fall back to offline heuristic when Gemini fails."""
        provider = GeminiProvider(api_key="valid-key")
        with patch.object(provider, "generate_content_rest", side_effect=RuntimeError("Gemini 503 Unavailable")):
            resp = provider.enrich_candidate(
                record_id="rec-1",
                entity_type="startup",
                target_field="ai_specialization",
                original_value=None,
                canonical_source_text="Some text",
                source_url="http://example.com",
                request_id="req-no-masquerade",
            )
            # Must record as FAILED and never return heuristic output
            self.assertFalse(resp.is_success)
            self.assertEqual(resp.status, "FAILED")
            self.assertIsNone(resp.proposed_value)
            self.assertIn("Gemini 503 Unavailable", resp.error_message)


if __name__ == "__main__":
    unittest.main()
