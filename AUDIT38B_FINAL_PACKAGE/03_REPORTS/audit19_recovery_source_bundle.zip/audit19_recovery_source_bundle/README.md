# Audit 19 Recovery Source Bundle

This bundle contains the actual original Audit 19 SQLite database previously uploaded in this conversation and exact exports of its `enrichment_audit_log` table.

## Source
- Database: `source/audit19_original_database.db`
- SHA-256: `1958c59f1a02e5a4bd274f114fdcfdd40942239f518eb662119962a263c84d4d`
- Original `enrichment_audit_log` rows: 366
- Unique `(record_id, entity_type, field_name)` keys: 366

## Independent comparison with the submitted Audit 23 database
- Original Audit 19 keys: 366
- Keys present in Audit 23 active/backup tables: 42
- Original keys absent from Audit 23 active/backup tables but recoverable from this original DB: 324
- Additional Audit 23 keys not in Audit 19: 24
- Full-row exact matches among current overlaps (active): 0
- Full-row exact matches among current overlaps (backup): 0

The row-level CSV is a reconciliation aid. It does not modify either database.

## Required use in Antigravity
1. Copy the original database into the project as a read-only source artifact.
2. Preserve all 366 rows exactly in a separate immutable archive table in the Audit 23 corrected database.
3. Do not overwrite current Audit 23 rows.
4. Rebuild the Audit 19 reconciliation by exact key and original field values, not by sorting current keys.
5. Keep the 24 post-Audit19 keys classified as later additions.
6. Regenerate the manifest after packaging.

This bundle is source evidence. It is not a replacement for the Audit 23 project package.
