# Daily AI Ecosystem Ingestion & Metric Refresh Report

**Execution Run ID:** `run_20261122_150000_221724`  
**Execution Type:** `ROUTINE_DAILY_INCREMENTAL`  
**Execution Start Time:** `2026-11-22T15:00:00+00:00` (UTC)  
**Execution Finish Time:** `2026-11-22T16:01:06.218004+00:00` (UTC)  
**Dynamic Rolling Window Start:** `2026-05-22T15:00:00+00:00` (UTC)  
**Dynamic Rolling Window End:** `2026-11-22T15:00:00+00:00` (UTC)  
**Rolling Window Duration:** Exactly 6 calendar months (UTC)  
**Canonical Database Preservation:** Verified Byte-Identical (`4949352d4f568f3f6128f398591cd8edac2eba45496c24535edb6c096398b95d`)  
**Authentic Audit 19 Archive Preservation:** Verified Byte-Identical (`1958c59f1a02e5a4bd274f114fdcfdd40942239f518eb662119962a263c84d4d`)  

---

## 1. Daily Ingestion & Modification Summary

| Pipeline Metric | Value | Category / Classification |
|---|:---:|---|
| **New Startups Discovered** | **+0** | Verified official domains |
| **New Products Discovered** | **+0** | Developer attribution verified |
| **New Research Papers** | **+0** | arXiv & Hugging Face papers |
| **New News Articles Ingested** | **+6** | 5 distinct legitimate media sources |
| **New Job Vacancies Ingested** | **+33** | Greenhouse ATS & Arbeitnow API |
| **GitHub Repository Metric Updates** | **15** | Live stars/forks snapshots appended |
| **Genuinely Published within 24h** | **30** | Strict `FRESH_24H` UTC window |
| **Duplicate Records Prevented** | **73** | Canonical URL & content hash match |

## 2. Dataset Eligibility Breakdown (Six-Month Rolling Window)

| Dataset / Table | Total Records | Valid Publication Date | Inside 6M Rolling Window | Outside Window (Archived) | Missing / Invalid Date | Future Anomalies |
|:---|:---:|:---:|:---:|:---:|:---:|:---:|
| `ai_startups` | 1,307 | 0 | 0 | 0 | 1,307 | 0 |
| `ai_products` | 1,316 | 0 | 0 | 0 | 1,316 | 0 |
| `ai_research_papers` | 1,060 | 1,060 | 1,060 | 0 | 0 | 0 |
| `ai_news` | 1,138 | 1,138 | 311 | 827 | 0 | 0 |
| `ai_jobs` | 1,963 | 1,963 | 1,931 | 32 | 0 | 0 |

### Supplementary GitHub Repositories & Snapshot Metrics

| Metric Entity | Active Records / Snapshots | Notes |
|:---|:---:|:---|
| `github_repositories` | 190 | Tracked open-source AI repositories linked to papers |
| `github_metrics_history` | 205 | Longitudinal star and fork delta timeline snapshots |

> [!IMPORTANT]
> **Permanent Historical Archive Preservation:** Zero records have been deleted. Records with missing publication dates (`MISSING_DATE`) and records older than 6 calendar months (`OUTSIDE_WINDOW`) remain permanently stored in the SQLite working archive (`data/working/rolling_ai_ecosystem.db`).

## 3. Phase III Multi-Tier LLM Token & Budget Consumption

| Metric | Status / Value | Operational Notes |
|:---|:---:|:---|
| **Phase III Pilot Status** | **DISABLED** | Routine daily execution (`run_pilot=False`) |
| **LLM Enrichment Requests** | 0 | Skipped in scheduled automation to conserve API budget |
| **Proposals Queue State** | **PENDING_APPROVAL** | All existing proposals preserved awaiting manual human review |
| **Database Mutability** | **ZERO WRITES** | No unapproved writes or schema changes applied |
| **Manual Execution Path** | `--run-pilot` | Can be triggered on-demand via CLI when required |

## 4. Execution Checkpoint & Scheduler Integrity

- **Scheduler Execution Status:** `COMPLETED`
- **Run ID:** `run_20261122_150000_221724`
- **Stage Level Resumed Stages:** `['STAGE_1_NEWS', 'STAGE_2_JOBS', 'STAGE_3_GITHUB_METRICS', 'STAGE_4_VACANCY_LIFECYCLE', 'STAGE_5_EXPORTS', 'STAGE_6_REPORT']`
- **Completed Pipeline Stages:** `['STAGE_1_NEWS', 'STAGE_2_JOBS', 'STAGE_3_GITHUB_METRICS', 'STAGE_4_VACANCY_LIFECYCLE', 'STAGE_5_EXPORTS', 'STAGE_6_REPORT']`
- **Checkpoint Saved:** Successfully recorded in `collection_logs` with run ID `run_20261122_150000_221724`.
- **Idempotency Guarantee:** Rerunning this pipeline on the same day will produce 0 duplicate records.
