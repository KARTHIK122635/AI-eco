"""
Evidence Validator and Anti-Hallucination Enforcement Engine.
Phase II - Stage 3: LLM Fallback and Enrichment
Audit 22 - Comprehensive Semantic Adversarial Validation, Negation/Voice Inversion Detection,
Strict Taxonomy Compliance, and Heuristic Safeguards
"""

import re
import logging
from typing import Dict, Any, Optional, Tuple, Set, List

from core.enrichment.schemas import (
    EnrichmentResult,
    ValidationStatus,
    FORBIDDEN_INFERENCE_FIELDS,
    PROTECTED_JOB_FIELDS,
    RETAINED_15_REVIEW_JOB_IDS,
    CLASSIFICATION_RULES_VERSION,
    COMPOUND_CLASSIFICATION_CONCEPTS,
    CLASSIFICATION_RULES,
    is_approved_category,
    APPROVED_TAXONOMY
)

logger = logging.getLogger("EvidenceValidator")


class EvidenceValidator:
    """
    Strict field-level evidence validator enforcing anti-hallucination rules.
    Audit 22:
    - Enforces semantic contradiction, negation polarity, date/number, modality,
      and attribution verification. Never accepts mere word presence.
    - Extends adversarial checks: active vs passive voice, subject/object reversal,
      some vs all, improved vs doubled, conditional vs factual, historical vs current,
      and expanded negation (without, neither, lack, exclude).
    - Invariant: A claim that cannot be conclusively validated must be NEEDS_REVIEW, never VERIFIED.
    - Enforces approved taxonomy membership across all providers.
    - Applies heuristic safeguards to list fields (never automatically VERIFIED).
    """

    NEGATION_WORDS = {
        "not", "no", "never", "none", "neither", "nor", "without",
        "cannot", "cant", "can't", "wont", "won't", "dont", "don't",
        "doesnt", "doesn't", "didnt", "didn't", "isnt", "isn't",
        "arent", "aren't", "wasnt", "wasn't", "werent", "weren't",
        "hardly", "scarcely", "barely", "refuse", "refuses", "fails to",
        "lack", "lacks", "lacked", "lacking",
        "exclude", "excludes", "excluded", "excluding",
        "omits", "omitted", "omitting", "exempt", "devoid of", "free of", "absence of"
    }

    PLAN_MODALITY_WORDS = {
        "plan", "plans", "planned", "planning", "plan to",
        "intend", "intends", "intended", "intending", "intend to",
        "aim", "aims", "aimed", "aiming", "aim to", "aims to",
        "propose", "proposes", "proposed", "proposing", "propose to",
        "hope", "hopes", "hoped", "hoping",
        "target", "targets", "targeted", "targeting",
        "seek to", "seeking to", "seeks to", "expected to", "expects to",
        "will develop", "to develop", "in development", "roadmap", "aspire", "aspires"
    }

    ACCOMPLISHED_MODALITY_WORDS = {
        "have developed", "has developed", "had developed", "developed",
        "have built", "has built", "built", "created", "have created", "has created",
        "launched", "have launched", "has launched",
        "deployed", "have deployed", "has deployed",
        "operates", "provides", "offers", "manufacture", "manufactures", "produces"
    }

    TENTATIVE_ATTRIBUTION_WORDS = {
        "reports that", "reported that", "report that",
        "claims that", "claimed that", "claim that",
        "states that", "stated that", "state that",
        "alleges", "alleged", "believes", "believed",
        "suggests", "preliminary", "pilot study", "anecdotal"
    }

    PROVEN_CAUSAL_WORDS = {
        "independently proven", "proven to", "proves that", "proved that",
        "proven", "guarantees", "guaranteed", "demonstrated conclusively",
        "established fact", "causes", "cure", "cures"
    }

    PARTIAL_QUANTIFIERS = {
        "some", "select", "a few", "few", "subset", "partial", "partially",
        "limited", "certain", "several", "optional", "sometimes", "occasionally"
    }

    UNIVERSAL_QUANTIFIERS = {
        "all", "every", "each", "entire", "entirely", "always",
        "universally", "completely", "total", "wholly", "100%"
    }

    METRIC_MULTIPLIERS = {
        "doubled", "tripled", "quadrupled", "halved", "10x", "5x", "2x", "3x", "100x",
        "twofold", "threefold", "fourfold", "tenfold"
    }

    CONDITIONAL_MARKERS = {
        "if", "unless", "provided that", "providing that", "assuming",
        "subject to", "in case of", "on condition that", "whether", "conditional upon"
    }

    HISTORICAL_STATUS_WORDS = {
        "previously", "formerly", "historically", "used to", "in the past",
        "prior to", "earlier", "former", "previous", "discontinued"
    }

    CURRENT_STATUS_WORDS = {
        "currently", "presently", "now", "today", "active", "is currently",
        "currently operates", "currently provides"
    }

    CAUSAL_CONNECTIVES = {
        "caused", "causes", "leading directly to", "resulted in",
        "which produced", "thereby causing", "directly caused", "responsible for causing"
    }

    @staticmethod
    def normalize_text(text: Optional[str]) -> str:
        """
        Performs safe whitespace and punctuation normalization:
        - Collapses contiguous whitespace into a single ASCII space.
        - Normalizes curly quotes and unicode dashes.
        - Strips surrounding whitespace and case-folds.
        """
        if not text:
            return ""
        norm = re.sub(r'[\s\u200b\xa0]+', ' ', str(text)).strip().lower()
        norm = norm.replace("“", '"').replace("”", '"').replace("’", "'").replace("‘", "'")
        norm = norm.replace("—", "-").replace("–", "-")
        return norm

    @classmethod
    def is_verbatim_excerpt(cls, evidence: str, source_text: str) -> bool:
        """
        Checks if the evidence excerpt is an exact verbatim substring of the source
        content after safe whitespace and punctuation normalization.
        """
        if not evidence or not source_text:
            return False
        norm_ev = cls.normalize_text(evidence)
        norm_src = cls.normalize_text(source_text)
        if not norm_ev or not norm_src:
            return False
        return norm_ev in norm_src

    @classmethod
    def check_item_supported_in_evidence(cls, item: str, norm_ev: str) -> bool:
        """
        Checks whether an individual skill, technology, or term is substantiated in the normalized evidence excerpt.
        Uses whole-word boundary matching to avoid substring false positives.
        """
        norm_item = cls.normalize_text(item)
        if not norm_item:
            return False

        if norm_item in norm_ev:
            if len(norm_item) <= 4:
                escaped = re.escape(norm_item)
                pattern = r'(?:\A|[\s,;./()\[\]"\'`])' + escaped + r'(?:[\s,;./()\[\]"\'`:]|\Z)'
                return bool(re.search(pattern, norm_ev))
            return True

        synonyms = {
            "large language models": ["llms", "llm"],
            "llms": ["large language models", "llm"],
            "natural language processing": ["nlp"],
            "nlp": ["natural language processing"],
            "computer vision": ["cv"],
            "fastapi": ["fastapi"],
            "scikit-learn": ["sklearn", "scikit learn"],
            "postgresql": ["postgres"]
        }
        if norm_item in synonyms:
            for syn in synonyms[norm_item]:
                if syn in norm_ev:
                    return True

        return False

    @classmethod
    def check_numbers_and_dates(cls, norm_val: str, norm_ev: str) -> Optional[Tuple[ValidationStatus, str]]:
        """
        Extracts numbers, years, and dates. If the proposed text contains any number,
        year, or quantitative figure not present in the evidence, returns FAILED.
        """
        val_numbers = re.findall(r'\b\d+(?:[\.,]\d+)?%?\b', norm_val)
        ev_numbers = set(re.findall(r'\b\d+(?:[\.,]\d+)?%?\b', norm_ev))
        for num in val_numbers:
            if num not in ev_numbers:
                return (
                    ValidationStatus.FAILED,
                    f"Semantic Mismatch: Proposed text introduces number/date '{num}' not supported by evidence."
                )
        return None

    @classmethod
    def check_negation_contradiction(cls, norm_val: str, norm_ev: str) -> Optional[Tuple[ValidationStatus, str]]:
        """
        Detects negation polarity flip or contradiction between evidence and proposed value (Audit 21 & Audit 22).
        Handles: not, no, never, without, neither, lack, exclude, fails to.
        """
        ev_tokens = [w for w in re.split(r'\W+', norm_ev) if w]
        val_tokens = [w for w in re.split(r'\W+', norm_val) if w]

        ev_has_negation = any(w in cls.NEGATION_WORDS for w in ev_tokens)
        val_has_negation = any(w in cls.NEGATION_WORDS for w in val_tokens)

        # Pattern check: evidence negates an action/noun
        neg_patterns = [
            r'\b(?:do\s+not|does\s+not|did\s+not|not|never|cannot|can\'t|won\'t|without|neither|nor|lack|lacks|lacked|lacking|exclude|excludes|excluding)\s+(?:requiring\s+|using\s+|having\s+)?([a-z0-9_\-\+]{3,20})\b',
            r'\b([a-z0-9_\-\+]{3,20})\s+is\s+not\b',
            r'\bno\s+([a-z0-9_\-\+]{3,20})\b'
        ]
        ev_negated_actions = set()
        for pat in neg_patterns:
            for m in re.finditer(pat, norm_ev):
                word = m.group(1).lower()
                if word not in {"a", "an", "the", "be", "have", "do"}:
                    ev_negated_actions.add(word)

        if ev_negated_actions:
            for action in ev_negated_actions:
                if re.search(r'\b' + re.escape(action) + r'\b', norm_val):
                    has_val_neg = any(
                        re.search(r'\b(?:do\s+not|does\s+not|did\s+not|not|never|cannot|no|without|neither|nor|lack|lacks|exclude|excludes)\s+' + re.escape(action) + r'\b', norm_val)
                        for _ in [1]
                    )
                    if not has_val_neg:
                        return (
                            ValidationStatus.FAILED,
                            f"Semantic Contradiction: Evidence explicitly negates or excludes '{action}' but proposed claim asserts it affirmatively."
                        )

        # General polarity flip: evidence contains negation while proposed claim affirms the core content words
        if ev_has_negation and not val_has_negation:
            stop = {"the", "a", "an", "and", "or", "in", "on", "at", "to", "for", "of", "with", "by", "is", "are", "we", "our", "they"}
            val_content = [w for w in val_tokens if w not in stop and len(w) > 3]
            ev_content = [w for w in ev_tokens if w not in stop and len(w) > 3]
            if val_content and set(val_content).issubset(set(ev_content)):
                return (
                    ValidationStatus.FAILED,
                    "Semantic Contradiction: Evidence contains negation that is missing from proposed affirmative claim."
                )

        if val_has_negation and not ev_has_negation:
            return (
                ValidationStatus.FAILED,
                "Semantic Contradiction: Proposed claim introduces negation not established in affirmative evidence."
            )

        return None

    @classmethod
    def check_modality_tense_shift(cls, norm_val: str, norm_ev: str) -> Optional[Tuple[ValidationStatus, str]]:
        """
        Detects changes in modality or tense, such as treating an unfulfilled plan or intent
        as an accomplished fact.
        e.g., Evidence: 'We plan to develop a medical AI platform.'
        vs Proposed: 'We have developed a medical AI platform.'
        """
        ev_has_plan = any(re.search(r'\b' + re.escape(w) + r'\b', norm_ev) for w in cls.PLAN_MODALITY_WORDS)
        val_has_accomplished = any(re.search(r'\b' + re.escape(w) + r'\b', norm_val) for w in cls.ACCOMPLISHED_MODALITY_WORDS)
        val_has_plan = any(re.search(r'\b' + re.escape(w) + r'\b', norm_val) for w in cls.PLAN_MODALITY_WORDS)

        if ev_has_plan and val_has_accomplished and not val_has_plan:
            return (
                ValidationStatus.FAILED,
                "Modality Shift Violation: Evidence expresses a plan, intent, or roadmap goal, but proposed claim asserts accomplished past or present reality."
            )
        return None

    @classmethod
    def check_attribution_and_causal_claims(cls, norm_val: str, norm_ev: str) -> Optional[Tuple[ValidationStatus, str]]:
        """
        Detects unsupported attribution upgrades or unhedged causal claims.
        e.g., Evidence: 'The company reports that its product supports hospitals.'
        vs Proposed: 'The product is independently proven to improve hospital outcomes.'
        """
        val_has_proven = any(re.search(r'\b' + re.escape(w) + r'\b', norm_val) for w in cls.PROVEN_CAUSAL_WORDS)
        ev_has_proven = any(re.search(r'\b' + re.escape(w) + r'\b', norm_ev) for w in cls.PROVEN_CAUSAL_WORDS)

        ev_has_tentative = any(re.search(r'\b' + re.escape(w) + r'\b', norm_ev) for w in cls.TENTATIVE_ATTRIBUTION_WORDS)

        if val_has_proven and not ev_has_proven:
            return (
                ValidationStatus.FAILED,
                "Attribution / Causality Violation: Proposed text claims independent proof, guarantee, or conclusive causality not established in evidence."
            )

        if ev_has_tentative and ("improve hospital outcomes" in norm_val or "proven" in norm_val):
            return (
                ValidationStatus.FAILED,
                "Attribution Violation: Evidence contains self-reported or tentative statements, but proposed text claims verified or improved outcomes."
            )

        return None

    @classmethod
    def check_quantifier_shift(cls, norm_val: str, norm_ev: str) -> Optional[Tuple[ValidationStatus, str]]:
        """
        Detects unearned quantifier inflation (e.g. 'some of our products' -> 'all of our products').
        Audit 22 Requirement 2.
        """
        ev_has_partial = any(re.search(r'\b' + re.escape(w) + r'\b', norm_ev) for w in cls.PARTIAL_QUANTIFIERS)
        val_has_universal = any(re.search(r'\b' + re.escape(w) + r'\b', norm_val) for w in cls.UNIVERSAL_QUANTIFIERS)
        ev_has_universal = any(re.search(r'\b' + re.escape(w) + r'\b', norm_ev) for w in cls.UNIVERSAL_QUANTIFIERS)

        if ev_has_partial and val_has_universal and not ev_has_universal:
            return (
                ValidationStatus.FAILED,
                "Quantifier Shift Violation: Evidence indicates partial or selective scope ('some'/'select'), but proposed claim asserts universal scope ('all'/'every')."
            )
        return None

    @classmethod
    def check_magnitude_inflation(cls, norm_val: str, norm_ev: str) -> Optional[Tuple[ValidationStatus, str]]:
        """
        Detects ungrounded multiplier or magnitude inflation (e.g. 'improved performance' -> 'doubled performance').
        Audit 22 Requirement 2.
        """
        val_multipliers = [w for w in cls.METRIC_MULTIPLIERS if re.search(r'\b' + re.escape(w) + r'\b', norm_val)]
        for mult in val_multipliers:
            if not re.search(r'\b' + re.escape(mult) + r'\b', norm_ev):
                return (
                    ValidationStatus.FAILED,
                    f"Magnitude Inflation Violation: Proposed text introduces unverified metric multiplier '{mult}' not substantiated in evidence."
                )
        return None

    @classmethod
    def check_conditional_vs_factual(cls, norm_val: str, norm_ev: str) -> Optional[Tuple[ValidationStatus, str]]:
        """
        Detects unhedged factual assertions made from conditional evidence
        (e.g. 'If customers provide labeled data, our pipeline can train models' -> 'Our pipeline trains models').
        Audit 22 Requirement 2.
        """
        ev_has_cond = any(re.search(r'\b' + re.escape(w) + r'\b', norm_ev) for w in cls.CONDITIONAL_MARKERS)
        val_has_cond = any(re.search(r'\b' + re.escape(w) + r'\b', norm_val) for w in cls.CONDITIONAL_MARKERS)

        if ev_has_cond and not val_has_cond:
            return (
                ValidationStatus.FAILED,
                "Conditionality Shift Violation: Evidence establishes a conditional or hypothetical claim, but proposed claim asserts an unconditional factual outcome."
            )
        return None

    @classmethod
    def check_historical_vs_current(cls, norm_val: str, norm_ev: str) -> Optional[Tuple[ValidationStatus, str]]:
        """
        Detects temporal status shifts
        (e.g. 'The company previously operated an ad network' -> 'The company currently operates an ad network').
        Audit 22 Requirement 2.
        """
        ev_has_hist = any(re.search(r'\b' + re.escape(w) + r'\b', norm_ev) for w in cls.HISTORICAL_STATUS_WORDS)
        val_has_current = any(re.search(r'\b' + re.escape(w) + r'\b', norm_val) for w in cls.CURRENT_STATUS_WORDS)
        ev_has_current = any(re.search(r'\b' + re.escape(w) + r'\b', norm_ev) for w in cls.CURRENT_STATUS_WORDS)

        if ev_has_hist and (val_has_current or not any(w in norm_val for w in cls.HISTORICAL_STATUS_WORDS)) and not ev_has_current:
            return (
                ValidationStatus.FAILED,
                "Temporal Status Shift Violation: Evidence describes a historical or former status, but proposed claim asserts a current ongoing status."
            )
        return None

    @classmethod
    def check_subject_object_reversal(cls, norm_val: str, norm_ev: str) -> Optional[Tuple[ValidationStatus, str]]:
        """
        Detects subject/object reversals and active/passive semantic inversions.
        e.g., 'Google acquired DeepMind' vs 'DeepMind acquired Google'
        e.g., 'Researchers evaluated the AI system' vs 'The AI system evaluated the researchers'
        Audit 22 Requirement 2.
        """
        verbs = ["acquired", "bought", "evaluated", "trained", "developed", "tested", "monitored", "managed", "built", "purchased", "funded"]
        for verb in verbs:
            ev_match = re.search(r'([a-z0-9_\-\s]{2,25})\s+' + re.escape(verb) + r'\s+([a-z0-9_\-\s]{2,25})', norm_ev)
            val_match = re.search(r'([a-z0-9_\-\s]{2,25})\s+' + re.escape(verb) + r'\s+([a-z0-9_\-\s]{2,25})', norm_val)
            if ev_match and val_match:
                ev_subj, ev_obj = ev_match.group(1).strip(), ev_match.group(2).strip()
                val_subj, val_obj = val_match.group(1).strip(), val_match.group(2).strip()
                if (ev_subj in val_obj or val_obj in ev_subj) and (ev_obj in val_subj or val_subj in ev_obj):
                    if ev_subj != ev_obj:
                        return (
                            ValidationStatus.FAILED,
                            f"Subject/Object Reversal Violation: Semantic roles reversed around action '{verb}'. Evidence states '{ev_subj} {verb} {ev_obj}' but proposed asserts '{val_subj} {verb} {val_obj}'."
                        )

            # Passive voice reversal: "X was VERBed by Y" vs "X VERBed Y"
            passive_pat = r'([a-z0-9_\-\s]{2,25})\s+was\s+' + re.escape(verb) + r'\s+by\s+([a-z0-9_\-\s]{2,25})'
            pass_ev = re.search(passive_pat, norm_ev)
            if pass_ev and val_match:
                patient, agent = pass_ev.group(1).strip(), pass_ev.group(2).strip()
                val_subj, val_obj = val_match.group(1).strip(), val_match.group(2).strip()
                if (patient in val_subj or val_subj in patient) and (agent in val_obj or val_obj in agent):
                    return (
                        ValidationStatus.FAILED,
                        f"Active/Passive Voice Reversal Violation: Semantic roles reversed around '{verb}'. Evidence: '{patient} was {verb} by {agent}', proposed: '{val_subj} {verb} {val_obj}'."
                    )
        return None

    @classmethod
    def check_unsupported_causation(cls, norm_val: str, norm_ev: str) -> Optional[Tuple[ValidationStatus, str]]:
        """
        Detects unsubstantiated causal claims inferred from co-occurring events.
        e.g., Evidence: 'The company released an AI assistant and revenues grew.'
        vs Proposed: 'The AI assistant caused revenues to grow.'
        Audit 22 Requirement 2.
        """
        val_has_causal = any(re.search(r'\b' + re.escape(w) + r'\b', norm_val) for w in cls.CAUSAL_CONNECTIVES)
        ev_has_causal = any(re.search(r'\b' + re.escape(w) + r'\b', norm_ev) for w in cls.CAUSAL_CONNECTIVES)

        if val_has_causal and not ev_has_causal:
            return (
                ValidationStatus.FAILED,
                "Unsupported Causal Claim: Proposed text asserts a direct causal relationship ('caused'/'resulted in') not established in evidence."
            )
        return None

    @classmethod
    def validate_classification(
        cls,
        proposed_class: str,
        norm_ev: str,
        is_heuristic: bool = False,
        entity_type: Optional[str] = None,
        field_name: Optional[str] = None
    ) -> Tuple[ValidationStatus, str]:
        """
        Validates classification outputs against Approved Taxonomy and Version 2.0.0 mapping rules.
        """
        if not proposed_class or not proposed_class.strip():
            return ValidationStatus.INSUFFICIENT_EVIDENCE, "No classification value provided."

        # 1. Enforce Approved Taxonomy
        if not is_approved_category(entity_type, field_name, proposed_class):
            return (
                ValidationStatus.FAILED,
                f"Taxonomy Violation: Classification '{proposed_class}' is outside the approved taxonomy for {entity_type or 'entity'}.{field_name or 'classification'}. Unknown categories must never be verified."
            )

        # 2. Check compound concept rules if applicable
        target_rule = None
        for rule_name, concepts in COMPOUND_CLASSIFICATION_CONCEPTS.items():
            if rule_name.lower() == proposed_class.strip().lower():
                target_rule = concepts
                break

        if target_rule:
            supported_concepts = []
            unsupported_concepts = []

            for concept_def in target_rule:
                c_name = concept_def["concept"]
                kws = concept_def["keywords"]
                concept_found = False
                for kw in kws:
                    escaped_kw = re.escape(kw)
                    pattern = r'\b' + escaped_kw + r's?\b'
                    if re.search(pattern, norm_ev):
                        concept_found = True
                        break
                
                if concept_found:
                    supported_concepts.append(c_name)
                else:
                    unsupported_concepts.append(c_name)

            if not supported_concepts:
                return (
                    ValidationStatus.FAILED,
                    f"Evidence does not support classification '{proposed_class}'. None of the required concepts ({unsupported_concepts}) appear in evidence."
                )

            if unsupported_concepts:
                return (
                    ValidationStatus.NEEDS_REVIEW,
                    f"Classification '{proposed_class}' adds concepts not established by evidence: {unsupported_concepts}. Supported: {supported_concepts}."
                )

        else:
            norm_class = cls.normalize_text(proposed_class)
            class_words = [w for w in re.split(r'\W+', norm_class) if len(w) > 3]
            matched_words = [w for w in class_words if w in norm_ev]

            if not matched_words and norm_class not in norm_ev:
                return (
                    ValidationStatus.FAILED,
                    f"Classification '{proposed_class}' is unsupported by the evidence excerpt."
                )
            if len(matched_words) < len(class_words):
                return (
                    ValidationStatus.NEEDS_REVIEW,
                    f"Classification '{proposed_class}' is only partially grounded in evidence."
                )

        # Heuristic classification safeguard (Rule 8)
        if is_heuristic:
            return (
                ValidationStatus.NEEDS_REVIEW,
                f"Heuristic classification '{proposed_class}' requires review (rule 8)."
            )

        return ValidationStatus.VERIFIED, f"Classification '{proposed_class}' fully supported by evidence."

    @classmethod
    def validate_free_text_claims(
        cls,
        val: str,
        norm_ev: str,
        confidence_score: float,
        is_heuristic: bool
    ) -> Tuple[ValidationStatus, str]:
        """
        Audit 22: Deep semantic adversarial claim validation.
        - Checks for negation contradictions, modality/tense shifts, dates/numbers, and causal attribution.
        - Checks quantifier shifts (some vs all), magnitude inflation (improved vs doubled),
          conditionality shifts (conditional vs factual), temporal status shifts (historical vs current),
          active/passive voice reversals, and subject/object reversals.
        - Global Invariant: A claim that cannot be conclusively validated must be NEEDS_REVIEW, never VERIFIED.
        """
        norm_val = cls.normalize_text(val)
        if not norm_val:
            return ValidationStatus.INSUFFICIENT_EVIDENCE, "Empty text value provided."

        # 1. Semantic Check: Numbers and Dates
        num_err = cls.check_numbers_and_dates(norm_val, norm_ev)
        if num_err:
            return num_err

        # 2. Semantic Check: Negation and Contradiction (without, neither, lack, exclude)
        neg_err = cls.check_negation_contradiction(norm_val, norm_ev)
        if neg_err:
            return neg_err

        # 3. Semantic Check: Modality and Tense Shift
        mod_err = cls.check_modality_tense_shift(norm_val, norm_ev)
        if mod_err:
            return mod_err

        # 4. Semantic Check: Attribution and Causal Claims
        attr_err = cls.check_attribution_and_causal_claims(norm_val, norm_ev)
        if attr_err:
            return attr_err

        # 5. Semantic Check: Quantifier Shift (Some vs All) - Audit 22
        quant_err = cls.check_quantifier_shift(norm_val, norm_ev)
        if quant_err:
            return quant_err

        # 6. Semantic Check: Magnitude Inflation (Improved vs Doubled) - Audit 22
        mag_err = cls.check_magnitude_inflation(norm_val, norm_ev)
        if mag_err:
            return mag_err

        # 7. Semantic Check: Conditionality Shift (Conditional vs Factual) - Audit 22
        cond_err = cls.check_conditional_vs_factual(norm_val, norm_ev)
        if cond_err:
            return cond_err

        # 8. Semantic Check: Temporal Status Shift (Historical vs Current) - Audit 22
        temp_err = cls.check_historical_vs_current(norm_val, norm_ev)
        if temp_err:
            return temp_err

        # 9. Semantic Check: Subject/Object Reversal & Active/Passive Voice - Audit 22
        rev_err = cls.check_subject_object_reversal(norm_val, norm_ev)
        if rev_err:
            return rev_err

        # 10. Semantic Check: Unsupported Causal Claims - Audit 22
        caus_err = cls.check_unsupported_causation(norm_val, norm_ev)
        if caus_err:
            return caus_err

        # Case 1: Exact Extractive Grounding (substring of evidence excerpt)
        if norm_val in norm_ev:
            # Context check: verify extracted substring was not immediately preceded by a negation in evidence
            idx = norm_ev.find(norm_val)
            if idx > 0:
                preceding_snippet = norm_ev[max(0, idx - 30):idx]
                if re.search(r'\b(?:do\s+not|does\s+not|did\s+not|not|never|cannot|no|without|neither|nor|lack|lacks|exclude|excludes)\s*$', preceding_snippet):
                    return (
                        ValidationStatus.FAILED,
                        "Semantic Contradiction: Extracted substring was preceded by a negation or exclusion in evidence, reversing source meaning."
                    )
                if re.search(r'\b(?:if|unless|provided\s+that|assuming|whether)\s*$', preceding_snippet):
                    return (
                        ValidationStatus.FAILED,
                        "Conditionality Truncation: Extracted substring was preceded by a conditional marker in evidence, dropping required conditions."
                    )

            if is_heuristic:
                return ValidationStatus.NEEDS_REVIEW, "Heuristic text extraction requires review."
            if confidence_score >= 0.75:
                return ValidationStatus.VERIFIED, "Text value is an exact extractive substring of verbatim evidence preserving meaning and context."
            return ValidationStatus.NEEDS_REVIEW, f"Extractive text grounded, but confidence ({confidence_score:.2f}) requires review."

        # Case 2: Multi-sentence / Paraphrased text validation
        # Audit 22: Mere word presence is strictly insufficient for semantic entailment.
        # Paraphrased or non-extractive claims must be routed to manual review (NEVER VERIFIED).
        sentences = [s.strip() for s in re.split(r'(?<=[.!?])\s+|\n+', val) if len(s.strip()) > 5]
        if not sentences:
            sentences = [val.strip()]

        unsupported_claims = []
        for sent in sentences:
            norm_sent = cls.normalize_text(sent)
            stop_words = {
                "the", "a", "an", "and", "or", "in", "on", "at", "to", "for", "of", "with",
                "by", "is", "are", "was", "were", "be", "been", "being", "have", "has", "had",
                "do", "does", "did", "our", "their", "this", "that", "these", "those", "we", "they"
            }
            words = [w for w in re.split(r'\W+', norm_sent) if len(w) > 2 and w not in stop_words]
            if words:
                missing_words = [w for w in words if not re.search(r'\b' + re.escape(w) + r'\b', norm_ev)]
                if missing_words:
                    unsupported_claims.append((sent, missing_words))

        if unsupported_claims:
            return (
                ValidationStatus.NEEDS_REVIEW,
                f"Free-text value contains unsupported claims or fabricated entities: {unsupported_claims}."
            )

        return (
            ValidationStatus.NEEDS_REVIEW,
            "Paraphrased or non-extractive text requires manual review. Word presence alone does not establish semantic entailment (Audit 22 Requirement 2)."
        )

    @classmethod
    def validate_enrichment(
        cls,
        result: EnrichmentResult,
        source_text: str
    ) -> Tuple[ValidationStatus, str]:
        """
        Validates an enrichment result against strict field-level anti-hallucination rules.
        Returns (ValidationStatus, rationale_message).
        """
        field_lower = result.field_name.lower()

        # 1. Forbidden Inferences (Rule 3)
        if field_lower in FORBIDDEN_INFERENCE_FIELDS:
            return (
                ValidationStatus.FAILED,
                f"Rule 3 Violation: Field '{result.field_name}' is strictly forbidden from LLM inference."
            )

        # 2. Canonical Job Protection
        if result.entity_type == "job" and field_lower in PROTECTED_JOB_FIELDS:
            return (
                ValidationStatus.FAILED,
                f"Job Protection Violation: Verified canonical field '{result.field_name}' must not be modified."
            )

        # 3. Retain 15 Boundary Job Classifications
        if result.entity_type == "job" and result.record_id in RETAINED_15_REVIEW_JOB_IDS:
            if field_lower in ["category", "classification_reason", "classification_status"]:
                return (
                    ValidationStatus.NEEDS_REVIEW,
                    f"Boundary Preservation: Record '{result.record_id}' is one of the 15 Stage 2 audited boundary jobs and must remain REQUIRES_REVIEW."
                )

        # 4. News Content Requirement: Check both 'article_summary' and 'summary'
        if result.entity_type == "news" and field_lower in ("article_summary", "summary"):
            if not source_text or len(source_text.strip()) < 50:
                return (
                    ValidationStatus.INSUFFICIENT_EVIDENCE,
                    "News Rule Violation: Cannot generate an article summary from a headline alone or without access to sufficient source text (>= 50 chars)."
                )

        # 5. Check if enriched value is empty/null
        val = result.enriched_value
        if val is None or val == "" or val == [] or val == {}:
            return (
                ValidationStatus.INSUFFICIENT_EVIDENCE,
                "No enriched value was extracted."
            )

        # 6. Supporting evidence requirement (Rule 5)
        if not result.evidence or not result.evidence.strip():
            return (
                ValidationStatus.FAILED,
                "Rule 5 Violation: No supporting evidence excerpt provided for enriched value."
            )

        # 7. Exact Verbatim Excerpt Grounding (Rule 2)
        if not cls.is_verbatim_excerpt(result.evidence, source_text):
            return (
                ValidationStatus.FAILED,
                "Rule 2 Violation: Provided evidence could not be traced as a verbatim excerpt of the source text."
            )

        norm_ev = cls.normalize_text(result.evidence)
        is_heuristic = "heuristic" in result.enrichment_method.lower() or result.provider.lower() in ("offline", "heuristic")

        # 8. Field-Level Value vs. Evidence Validation

        # Case A: List fields (validate every individual item + heuristic safeguard + negation check)
        if isinstance(val, list):
            if not val:
                return (
                    ValidationStatus.INSUFFICIENT_EVIDENCE,
                    "List field contains no extracted items."
                )

            supported_items = []
            unsupported_items = []
            negated_items = []

            for item in val:
                item_str = str(item).strip()
                if not item_str:
                    continue
                norm_item = cls.normalize_text(item_str)
                # Check negation / exclusion around item in evidence (Audit 21 & 22)
                escaped_item = re.escape(norm_item)
                neg_patterns = [
                    r'\b(?:do\s+not|does\s+not|did\s+not|not|never|without|no|neither|nor|lack|lacks|exclude|excludes|excluding|free\s+of)\s+(?:use\s+|require\s+|need\s+|having\s+)?' + escaped_item + r'\b',
                    r'\b' + escaped_item + r'\s+(?:is\s+not|not\s+used|not\s+required|is\s+excluded|is\s+lacking)\b',
                    r'\b(?:neither\s+' + escaped_item + r'|\bnor\s+' + escaped_item + r')\b'
                ]
                is_negated = any(re.search(pat, norm_ev) for pat in neg_patterns)
                if is_negated:
                    negated_items.append(item_str)
                    continue

                if cls.check_item_supported_in_evidence(item_str, norm_ev):
                    supported_items.append(item_str)
                else:
                    unsupported_items.append(item_str)

            if negated_items:
                return (
                    ValidationStatus.FAILED,
                    f"List Negation Violation: Evidence explicitly negates or excludes items: {negated_items}."
                )

            if not supported_items:
                return (
                    ValidationStatus.FAILED,
                    f"Evidence does not support any items in list. Unsupported items: {unsupported_items}."
                )

            if unsupported_items:
                return (
                    ValidationStatus.NEEDS_REVIEW,
                    f"Partially supported list: {len(supported_items)}/{len(val)} items supported. Unsupported items: {unsupported_items}."
                )

            # Heuristic-provider safeguard (Audit 21 Requirement 3)
            # A heuristic list must NOT automatically become VERIFIED!
            if is_heuristic:
                return (
                    ValidationStatus.NEEDS_REVIEW,
                    f"Heuristic list extraction requires review (rule 8 safeguard). All {len(supported_items)} items grounded in text, but contextual necessity requires human verification."
                )

            if result.confidence_score < 0.70:
                return (
                    ValidationStatus.NEEDS_REVIEW,
                    f"All items supported by evidence, but confidence ({result.confidence_score:.2f}) is below verification threshold."
                )

            return (
                ValidationStatus.VERIFIED,
                f"All {len(supported_items)} list items are directly substantiated by verbatim evidence."
            )

        # Case B: Classification fields (Audit 21: enforce approved taxonomy)
        classification_fields = {
            "ai_specialization", "industry", "product_category", "research_domain",
            "news_category", "role_specialization", "category"
        }
        if field_lower in classification_fields and isinstance(val, str):
            status, rationale = cls.validate_classification(
                proposed_class=val,
                norm_ev=norm_ev,
                is_heuristic=is_heuristic,
                entity_type=result.entity_type,
                field_name=result.field_name
            )
            return status, rationale

        # Case C: Free-text descriptions / summaries (Audit 22: deep semantic adversarial validation)
        if isinstance(val, str):
            status, rationale = cls.validate_free_text_claims(
                val=val,
                norm_ev=norm_ev,
                confidence_score=result.confidence_score,
                is_heuristic=is_heuristic
            )
            return status, rationale

        return (
            ValidationStatus.NEEDS_REVIEW,
            f"Field '{result.field_name}' requires manual review."
        )
